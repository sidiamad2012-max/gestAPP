export function TestComponent() {
  return (
    <div className="p-6">
      <h1>Test Component - L'application fonctionne</h1>
    </div>
  );
}